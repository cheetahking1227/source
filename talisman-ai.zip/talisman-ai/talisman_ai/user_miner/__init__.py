"""User miner module for custom implementation."""

from talisman_ai.user_miner.my_miner import MyMiner

__all__ = ['MyMiner']

