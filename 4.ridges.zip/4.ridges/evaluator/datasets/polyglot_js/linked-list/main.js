//
// This is only a SKELETON file for the 'Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class LinkedList {
  push() {
    throw new Error('Remove this line and implement the function');
  }

  pop() {
    throw new Error('Remove this line and implement the function');
  }

  shift() {
    throw new Error('Remove this line and implement the function');
  }

  unshift() {
    throw new Error('Remove this line and implement the function');
  }

  delete() {
    throw new Error('Remove this line and implement the function');
  }

  count() {
    throw new Error('Remove this line and implement the function');
  }
}
