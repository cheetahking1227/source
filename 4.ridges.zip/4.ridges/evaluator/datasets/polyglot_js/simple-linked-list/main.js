//
// This is only a SKELETON file for the 'Simple Linked List' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Element {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get value() {
    throw new Error('Remove this line and implement the function');
  }

  get next() {
    throw new Error('Remove this line and implement the function');
  }
}

export class List {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  add(nextValue) {
    throw new Error('Remove this line and implement the function');
  }

  get length() {
    throw new Error('Remove this line and implement the function');
  }

  get head() {
    throw new Error('Remove this line and implement the function');
  }

  toArray() {
    throw new Error('Remove this line and implement the function');
  }

  reverse() {
    throw new Error('Remove this line and implement the function');
  }
}
