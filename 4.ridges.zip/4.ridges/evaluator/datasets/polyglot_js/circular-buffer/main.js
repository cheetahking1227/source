//
// This is only a SKELETON file for the 'Circular Buffer' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

class CircularBuffer {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  write() {
    throw new Error('Remove this line and implement the function');
  }

  read() {
    throw new Error('Remove this line and implement the function');
  }

  forceWrite() {
    throw new Error('Remove this line and implement the function');
  }

  clear() {
    throw new Error('Remove this line and implement the function');
  }
}

export default CircularBuffer;

export class BufferFullError extends Error {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }
}

export class BufferEmptyError extends Error {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }
}
