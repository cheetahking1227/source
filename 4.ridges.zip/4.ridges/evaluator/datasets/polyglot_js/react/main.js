//
// This is only a SKELETON file for the 'React' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class InputCell {
  constructor(value) {
    throw new Error('Remove this line and implement the function');
  }

  setValue(value) {
    throw new Error('Remove this line and implement the function');
  }
}

export class ComputeCell {
  constructor(inputCells, fn) {
    throw new Error('Remove this line and implement the function');
  }

  addCallback(cb) {
    throw new Error('Remove this line and implement the function');
  }

  removeCallback(cb) {
    throw new Error('Remove this line and implement the function');
  }
}

export class CallbackCell {
  constructor(fn) {
    throw new Error('Remove this line and implement the function');
  }
}
