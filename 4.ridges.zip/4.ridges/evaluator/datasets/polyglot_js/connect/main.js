//
// This is only a SKELETON file for the 'Connect' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Board {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  winner() {
    throw new Error('Remove this line and implement the function');
  }
}
