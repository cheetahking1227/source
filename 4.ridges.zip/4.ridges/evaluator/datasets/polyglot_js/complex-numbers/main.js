//
// This is only a SKELETON file for the 'Complex Numbers' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class ComplexNumber {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get real() {
    throw new Error('Remove this line and implement the function');
  }

  get imag() {
    throw new Error('Remove this line and implement the function');
  }

  add() {
    throw new Error('Remove this line and implement the function');
  }

  sub() {
    throw new Error('Remove this line and implement the function');
  }

  div() {
    throw new Error('Remove this line and implement the function');
  }

  mul() {
    throw new Error('Remove this line and implement the function');
  }

  get abs() {
    throw new Error('Remove this line and implement the function');
  }

  get conj() {
    throw new Error('Remove this line and implement the function');
  }

  get exp() {
    throw new Error('Remove this line and implement the function');
  }
}
