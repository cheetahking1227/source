//
// This is only a SKELETON file for the 'High Scores' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class HighScores {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get scores() {
    throw new Error('Remove this line and implement the function');
  }

  get latest() {
    throw new Error('Remove this line and implement the function');
  }

  get personalBest() {
    throw new Error('Remove this line and implement the function');
  }

  get personalTopThree() {
    throw new Error('Remove this line and implement the function');
  }
}
