# Instructions

Your task is to count the number of 1 bits in the binary representation of a number.

## Restrictions

Keep your hands off that bit-count functionality provided by your standard library!
Solve this one yourself using other basic tools instead.
