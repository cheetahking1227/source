//
// This is only a SKELETON file for the 'Rational Numbers' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Rational {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  add() {
    throw new Error('Remove this line and implement the function');
  }

  sub() {
    throw new Error('Remove this line and implement the function');
  }

  mul() {
    throw new Error('Remove this line and implement the function');
  }

  div() {
    throw new Error('Remove this line and implement the function');
  }

  abs() {
    throw new Error('Remove this line and implement the function');
  }

  exprational() {
    throw new Error('Remove this line and implement the function');
  }

  expreal() {
    throw new Error('Remove this line and implement the function');
  }

  reduce() {
    throw new Error('Remove this line and implement the function');
  }
}
