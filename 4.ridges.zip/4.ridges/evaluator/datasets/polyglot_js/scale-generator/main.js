//
// This is only a SKELETON file for the 'Scale Generator' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Scale {
  constructor(tonic) {
    throw new Error('Remove this line and implement the function');
  }

  chromatic() {
    throw new Error('Remove this line and implement the function');
  }

  interval(intervals) {
    throw new Error('Remove this line and implement the function');
  }
}
