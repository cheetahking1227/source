//
// This is only a SKELETON file for the 'Space Age' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const age = () => {
  throw new Error('Remove this line and implement the function');
};
