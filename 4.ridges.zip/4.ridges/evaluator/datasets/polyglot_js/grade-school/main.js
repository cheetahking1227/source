//
// This is only a SKELETON file for the 'Grade School' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class GradeSchool {
  roster() {
    throw new Error('Remove this line and implement the function');
  }

  add() {
    throw new Error('Remove this line and implement the function');
  }

  grade() {
    throw new Error('Remove this line and implement the function');
  }
}
