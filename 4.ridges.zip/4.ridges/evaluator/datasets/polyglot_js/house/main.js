//
// This is only a SKELETON file for the 'House' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class House {
  static verse() {
    throw new Error('Remove this line and implement the function');
  }

  static verses() {
    throw new Error('Remove this line and implement the function');
  }
}
