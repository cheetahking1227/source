//
// This is only a SKELETON file for the 'Rest API' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class RestAPI {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get(url) {
    throw new Error('Remove this line and implement the function');
  }

  post(url, payload) {
    throw new Error('Remove this line and implement the function');
  }
}
