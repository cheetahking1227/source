export const encode = (phrase, key) => {
  throw new Error('Remove this line and implement the function');
};

export const decode = (phrase, key) => {
  throw new Error('Remove this line and implement the function');
};
