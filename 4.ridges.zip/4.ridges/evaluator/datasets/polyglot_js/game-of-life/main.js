//
// This is only a SKELETON file for the 'Conway's Game of Life' exercise. It's been provided
// as a convenience to get you started writing code faster.
//

export class GameOfLife {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  tick() {
    throw new Error('Remove this line and implement the function');
  }

  state() {
    throw new Error('Remove this line and implement the function');
  }
}
