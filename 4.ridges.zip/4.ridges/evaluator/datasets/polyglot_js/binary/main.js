//
// This is only a SKELETON file for the 'Binary' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Binary {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  toDecimal() {
    throw new Error('Remove this line and implement the function');
  }
}
