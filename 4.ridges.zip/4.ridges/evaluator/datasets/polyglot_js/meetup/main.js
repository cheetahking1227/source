//
// This is only a SKELETON file for the 'Meetup' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const meetup = () => {
  throw new Error('Remove this line and implement the function');
};
