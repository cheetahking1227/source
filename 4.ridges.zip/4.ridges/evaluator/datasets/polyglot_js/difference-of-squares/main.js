//
// This is only a SKELETON file for the 'Difference Of Squares' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Squares {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get sumOfSquares() {
    throw new Error('Remove this line and implement the function');
  }

  get squareOfSum() {
    throw new Error('Remove this line and implement the function');
  }

  get difference() {
    throw new Error('Remove this line and implement the function');
  }
}
