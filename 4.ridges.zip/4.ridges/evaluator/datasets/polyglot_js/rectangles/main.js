//
// This is only a SKELETON file for the 'Rectangles' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export function count() {
  throw new Error('Remove this line and implement the function');
}
