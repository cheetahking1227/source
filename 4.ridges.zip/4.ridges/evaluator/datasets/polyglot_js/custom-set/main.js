//
// This is only a SKELETON file for the 'Custom Set' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class CustomSet {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  empty() {
    throw new Error('Remove this line and implement the function');
  }

  contains() {
    throw new Error('Remove this line and implement the function');
  }

  add() {
    throw new Error('Remove this line and implement the function');
  }

  subset() {
    throw new Error('Remove this line and implement the function');
  }

  disjoint() {
    throw new Error('Remove this line and implement the function');
  }

  eql() {
    throw new Error('Remove this line and implement the function');
  }

  union() {
    throw new Error('Remove this line and implement the function');
  }

  intersection() {
    throw new Error('Remove this line and implement the function');
  }

  difference() {
    throw new Error('Remove this line and implement the function');
  }
}
