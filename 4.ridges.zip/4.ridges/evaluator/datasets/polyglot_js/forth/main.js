//
// This is only a SKELETON file for the 'Forth' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Forth {
  constructor() {
    throw Error('Remove this statement and implement this function');
  }

  evaluate() {
    throw Error('Remove this statement and implement this function');
  }

  get stack() {
    throw Error('Remove this statement and implement this function');
  }
}
