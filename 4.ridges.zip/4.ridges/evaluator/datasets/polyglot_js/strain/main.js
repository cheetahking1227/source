//
// This is only a SKELETON file for the 'Strain' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const keep = () => {
  throw new Error('Remove this line and implement the function');
};

export const discard = () => {
  throw new Error('Remove this line and implement the function');
};
