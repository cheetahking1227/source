//
// This is only a SKELETON file for the 'Point Mutations' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class DNA {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  hammingDistance() {
    throw new Error('Remove this line and implement the function');
  }
}
