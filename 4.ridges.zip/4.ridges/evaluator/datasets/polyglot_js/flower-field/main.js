//
// This is only a SKELETON file for the 'Flower Field' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const annotate = (input) => {
  throw new Error('Remove this statement and implement this function');
};
