//
// This is only a SKELETON file for the 'Series' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Series {
  constructor(series) {
    throw new Error('Remove this line and implement the function');
  }

  slices(sliceLength) {
    throw new Error('Remove this line and implement the function');
  }
}
