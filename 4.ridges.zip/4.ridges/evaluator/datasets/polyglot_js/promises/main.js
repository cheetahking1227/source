//
// This is only a SKELETON file for the 'Promises' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const promisify = () => {
  throw new Error('Remove this line and implement the function');
};

export const all = () => {
  throw new Error('Remove this line and implement the function');
};

export const allSettled = () => {
  throw new Error('Remove this line and implement the function');
};

export const race = () => {
  throw new Error('Remove this line and implement the function');
};

export const any = () => {
  throw new Error('Remove this line and implement the function');
};
