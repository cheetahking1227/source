//
// This is only a SKELETON file for the 'Sublist' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class List {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  compare() {
    throw new Error('Remove this line and implement the function');
  }
}
