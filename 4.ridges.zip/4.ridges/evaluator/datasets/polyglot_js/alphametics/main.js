//
// This is only a SKELETON file for the 'Alphametics' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const solve = () => {
  throw new Error('Remove this line and implement the function');
};
