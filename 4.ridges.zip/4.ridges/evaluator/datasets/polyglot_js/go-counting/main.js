//
// This is only a SKELETON file for the 'Go Counting' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class GoCounting {
  constructor(board) {
    throw new Error('Remove this line and implement the function');
  }

  getTerritory(x, y) {
    throw new Error('Remove this line and implement the function');
  }

  getTerritories() {
    throw new Error('Remove this line and implement the function');
  }
}
