//
// This is only a SKELETON file for the 'Queen Attack' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class QueenAttack {
  constructor({
    black: [blackRow, blackColumn] = [],
    white: [whiteRow, whiteColumn] = [],
  } = {}) {
    throw new Error('Remove this line and implement the function');
  }

  toString() {
    throw new Error('Remove this line and implement the function');
  }

  get canAttack() {
    throw new Error('Remove this line and implement the function');
  }
}
