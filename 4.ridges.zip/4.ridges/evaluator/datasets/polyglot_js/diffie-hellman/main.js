//
// This is only a SKELETON file for the 'Diffie Hellman' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class DiffieHellman {
  constructor(p, g) {
    throw new Error('Remove this line and implement the function');
  }

  getPublicKey(privateKey) {
    throw new Error('Remove this line and implement the function');
  }

  getSecret(theirPublicKey, myPrivateKey) {
    throw new Error('Remove this line and implement the function');
  }

  getPrivateKey() {
    throw new Error('Remove this line and implement the function');
  }
}
