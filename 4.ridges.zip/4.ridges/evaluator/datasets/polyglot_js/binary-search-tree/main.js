//
// This is only a SKELETON file for the 'Binary Search Tree' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class BinarySearchTree {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get data() {
    throw new Error('Remove this line and implement the function');
  }
  get right() {
    throw new Error('Remove this line and implement the function');
  }

  get left() {
    throw new Error('Remove this line and implement the function');
  }

  insert() {
    throw new Error('Remove this line and implement the function');
  }

  each() {
    throw new Error('Remove this line and implement the function');
  }
}
