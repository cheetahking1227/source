//
// This is only a SKELETON file for the 'Food Chain' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Song {
  verse() {
    throw new Error('Remove this line and implement the function');
  }

  verses() {
    throw new Error('Remove this line and implement the function');
  }
}
