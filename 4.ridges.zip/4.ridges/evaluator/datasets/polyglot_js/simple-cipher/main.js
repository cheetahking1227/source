//
// This is only a SKELETON file for the 'Simple Cipher' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Cipher {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  encode() {
    throw new Error('Remove this line and implement the function');
  }

  decode() {
    throw new Error('Remove this line and implement the function');
  }

  get key() {
    throw new Error('Remove this line and implement the function');
  }
}
