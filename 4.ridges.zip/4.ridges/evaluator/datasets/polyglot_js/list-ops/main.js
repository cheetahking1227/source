//
// This is only a SKELETON file for the 'List Ops' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class List {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  append() {
    throw new Error('Remove this line and implement the function');
  }

  concat() {
    throw new Error('Remove this line and implement the function');
  }

  filter() {
    throw new Error('Remove this line and implement the function');
  }

  map() {
    throw new Error('Remove this line and implement the function');
  }

  length() {
    throw new Error('Remove this line and implement the function');
  }

  foldl() {
    throw new Error('Remove this line and implement the function');
  }

  foldr() {
    throw new Error('Remove this line and implement the function');
  }

  reverse() {
    throw new Error('Remove this line and implement the function');
  }
}
