export const degreesOfSeparation = (familyTree, personA, personB) => {
  throw new Error('Remove this line and implement the function');
};
