//
// This is only a SKELETON file for the 'Pythagorean Triplet' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export function triplets({ minFactor, maxFactor, sum }) {
  throw new Error('Remove this line and implement the function');
}

class Triplet {
  constructor(a, b, c) {
    throw new Error('Remove this line and implement the function');
  }

  toArray() {
    throw new Error('Remove this line and implement the function');
  }
}
