//
// This is only a SKELETON file for the 'Matrix' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Matrix {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get rows() {
    throw new Error('Remove this line and implement the function');
  }

  get columns() {
    throw new Error('Remove this line and implement the function');
  }
}
