//
// This is only a SKELETON file for the 'Clock' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Clock {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  toString() {
    throw new Error('Remove this line and implement the function');
  }

  plus() {
    throw new Error('Remove this line and implement the function');
  }

  minus() {
    throw new Error('Remove this line and implement the function');
  }

  equals() {
    throw new Error('Remove this line and implement the function');
  }
}
