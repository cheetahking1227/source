//
// This is only a SKELETON file for the 'Allergies' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Allergies {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  list() {
    throw new Error('Remove this line and implement the function');
  }

  allergicTo() {
    throw new Error('Remove this line and implement the function');
  }
}
