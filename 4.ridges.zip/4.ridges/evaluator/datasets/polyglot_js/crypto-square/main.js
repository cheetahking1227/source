//
// This is only a SKELETON file for the 'Crypto Square' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class Crypto {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  get ciphertext() {
    throw new Error('Remove this line and implement the function');
  }
}
