//
// This is only a SKELETON file for the 'Bank Account' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export class BankAccount {
  constructor() {
    throw new Error('Remove this line and implement the function');
  }

  open() {
    throw new Error('Remove this line and implement the function');
  }

  close() {
    throw new Error('Remove this line and implement the function');
  }

  deposit() {
    throw new Error('Remove this line and implement the function');
  }

  withdraw() {
    throw new Error('Remove this line and implement the function');
  }

  get balance() {
    throw new Error('Remove this line and implement the function');
  }
}

export class ValueError extends Error {
  constructor() {
    super('Bank account error');
  }
}
