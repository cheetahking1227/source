//
// This is only a SKELETON file for the 'D&D Character' exercise. It's been provided as a
// convenience to get you started writing code faster.
//

export const abilityModifier = () => {
  throw new Error('Remove this line and implement the function');
};

export class Character {
  static rollAbility() {
    throw new Error('Remove this line and implement the function');
  }

  get strength() {
    throw new Error('Remove this line and implement the function');
  }

  get dexterity() {
    throw new Error('Remove this line and implement the function');
  }

  get constitution() {
    throw new Error('Remove this line and implement the function');
  }

  get intelligence() {
    throw new Error('Remove this line and implement the function');
  }

  get wisdom() {
    throw new Error('Remove this line and implement the function');
  }

  get charisma() {
    throw new Error('Remove this line and implement the function');
  }

  get hitpoints() {
    throw new Error('Remove this line and implement the function');
  }
}
