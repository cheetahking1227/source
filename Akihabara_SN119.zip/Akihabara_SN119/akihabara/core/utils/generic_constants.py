ORGANIC="organic"
SYNTHETIC="synthetic"
ACKNLOWEDGED="acknowledged"
ERROR="error"
STATUS_CODE="status_code"
ERROR_MESSAGE="error_message"
JOB_ID="job_id"
CONTENT="content"

# organic contenders selection parameters
ORGANIC_SELECT_CONTENDER_LOW_POURC=0.75
ORGANIC_TOP_POURC=0.35
ORGANIC_TOP_POURC_FACTOR=5
