MINER_TEST_DB_NAME = "miner_unit_testing"
VALIDATOR_TEST_DB_NAME = "validator_unit_testing"