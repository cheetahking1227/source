# External I/O boundaries for JobRegistry

