# Changelog

All notable changes to this project will be documented in this file.

## [0.2.13] - 2025-01-26

### 🚀 Features

- Gradient analysis
- Similarities

### 🐛 Bug Fixes

- Missing graidient logic

### ⚙️ Miscellaneous Tasks

- Rename to r2
- Ignore types
- Analyer tables

