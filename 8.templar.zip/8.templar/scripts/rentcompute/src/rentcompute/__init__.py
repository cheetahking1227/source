"""
rentcompute - A CLI tool for renting compute instances
"""

__version__ = "0.1.0"
